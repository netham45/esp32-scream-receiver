
#ifndef CONFIG_H
#define CONFIG_H
#define AUDIO_BUFFER_SIZE 2048
#endif
