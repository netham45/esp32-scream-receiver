
#include "network.h"
void network_init(void) {}
void network_driver_event(int event_id) {}
