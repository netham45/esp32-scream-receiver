
#ifndef SECRET_CREDENTIALS_H
#define SECRET_CREDENTIALS_H
#define WIFI_SSID "your_ssid"
#define WIFI_PASS "your_pass"
#endif
