
#ifndef NETWORK_H
#define NETWORK_H
void network_init(void);
void network_driver_event(int event_id);
#endif
